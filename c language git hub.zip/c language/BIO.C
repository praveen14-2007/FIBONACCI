#include <stdio.h>
int main() {
    //My Bio data
    printf("name : susesh");
 printf("sudying btech first year in btech \n");
 printf("my blood group is Opositive");
 return 0;
} 