#include <stdio.h>
int main() {
    int a=100 , b=5 ,c ;
    c = a/b;
    printf("div =%d",c);
    return 0;
}