#include <stdio.h>
int main() {
    int a=30 , b=50 ,c ;
    c = a*b;
    printf("multi =%d",c);
    return 0;
}
