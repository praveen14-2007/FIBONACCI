#include <stdio.h>
int main() {
    int a, b, c;
    printf("entera&b values");
    scanf("%d%d",&a,&b);
    c=a+b;
    printf("sum=%d",c);
    return 0;
}