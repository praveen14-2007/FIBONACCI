#include <stdio.h>
int main() {
    char c[25] ;
    printf("enter name of the student");
    scanf("%s",&c);
    printf("name : %s",c);
    return 0;
}