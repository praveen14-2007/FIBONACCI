//addition
#include<stdio.h>
int main() 
{
    //int a=10,b=20,c;
    int a,b,c;
    printf("entera&b values");
    scanf("%d%d",&a,&b);
    c=a+b;
    printf("sum=%d",c);
    return 0;
}