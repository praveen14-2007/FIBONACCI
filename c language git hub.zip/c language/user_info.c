//displaying user info
#include <stdio.h>
int main() {
    printf("Name\t:\tsusesh\nphoneno\t:\t855906238\naddress\t:\tnandyal");
    
}