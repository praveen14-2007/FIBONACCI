#include <stdio.h>
int main() {
    char b ;
    printf("name of the student:  ");
    scanf("%c",&b);
    printf("the name of the student is: %c",b);
    return 0;
}