#include <stdio.h>
int main()
{
    //new program
    printf("hello");
    return 0;
    }