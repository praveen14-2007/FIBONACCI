#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

int main()
{ float n,m;
	scanf("%f %f",&n,&m);
    printf("%.1f %.1f",m+n,n-m);
    return 0;
}