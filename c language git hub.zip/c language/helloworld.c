#include <stdio.h>
int main() {
    //my first pogram
    printf("hello world");
    return 0;
}