#include <stdio.h>
int main() {
    int r = 20 , pi = 3.14 , area ;
    area = pi*r*r ;
    printf("area =%d",area);
    return 0;
}