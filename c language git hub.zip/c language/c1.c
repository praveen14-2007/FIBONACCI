#include <stdio.h>
int main() {
    int p=100 , r=12 ,t=10 , s ;
    s = (p*r*t)/100 ;
    printf("s=%d",s);
    return 0;
}