#include <stdio.h>
int main() {
    int a=30 , b=5 ,c ;
    c = a-b;
    printf("sub =%d",c);
    return 0;
}