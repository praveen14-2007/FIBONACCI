//addition
#include<stdio.h>
int main() 
{
    //float a=10,b=20,c;
    float a,b,c;
    printf("entera&b values");
    scanf("%f%f",&a,&b);
    c=a+b;
    printf("sum=%f",c);
    return 0;
}