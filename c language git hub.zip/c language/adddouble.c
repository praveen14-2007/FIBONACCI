//addition
#include<stdio.h>
int main() 
{
    //double a=10,b=20,c;
    double a,b,c;
    printf("entera&b values");
    scanf("%lf%lf",&a,&b);
    c=a+b;
    printf("sum=%lf",c);
    return 0;
}