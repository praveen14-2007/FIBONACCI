#include <stdio.h>
int main() {
    int a =65 ;
    char b = (char)65;
    printf("%c",b);
    return 0;
}

