#include <stdio.h>
int main()
{
    int x;
    float y;
    char z;
    scanf("%x");
}