#include <stdio.h>
int main() {
    int a=10, b=20, c ;
    c =a+b;
    printf("sum =%d",c);
    return 0;
}
